using CarRentalAPI.Data;
using CarRentalAPI.Models;
using Dapper;
using Microsoft.AspNetCore.Mvc;

namespace CarRentalAPI.Controllers;

[ApiController]
[Route("api/[controller]")]
public class RentalsController : ControllerBase
{
    private readonly DbContext _db;
    public RentalsController(DbContext db) => _db = db;

    [HttpGet]
    public async Task<IActionResult> GetAll([FromQuery] string? status)
    {
        using var conn = _db.CreateConnection();
        var where = string.IsNullOrEmpty(status) ? "" : "WHERE r.Status = @status";
        var rows = await conn.QueryAsync<Rental>($@"
            SELECT r.RentalID,
                r.CustomerID, c.FirstName + ' ' + c.LastName AS CustomerName,
                r.VehicleID, v.Make + ' ' + v.Model AS VehicleInfo,
                v.LicensePlate, cat.CategoryName,
                r.PickupLocationID, pl.Name AS PickupBranch,
                r.DropoffLocationID, dl.Name AS DropoffBranch,
                r.PickupDate, r.ReturnDate, r.DailyRate, r.TotalAmount, r.Status,
                r.PromoID, pr.Code AS PromoCode, pr.Discount
            FROM rentals r
            JOIN customers c ON r.CustomerID = c.CustomerID
            JOIN vehicles v ON r.VehicleID = v.VehicleID
            JOIN vehicle_categories cat ON v.CategoryID = cat.CategoryID
            JOIN rental_locations pl ON r.PickupLocationID = pl.LocationID
            JOIN rental_locations dl ON r.DropoffLocationID = dl.LocationID
            LEFT JOIN promotions pr ON r.PromoID = pr.PromoID
            {where}
            ORDER BY r.RentalID DESC", new { status });
        return Ok(rows);
    }

    [HttpGet("{id}")]
    public async Task<IActionResult> GetById(int id)
    {
        using var conn = _db.CreateConnection();
        var row = await conn.QueryFirstOrDefaultAsync<Rental>(@"
            SELECT r.RentalID,
                r.CustomerID, c.FirstName + ' ' + c.LastName AS CustomerName,
                r.VehicleID, v.Make + ' ' + v.Model AS VehicleInfo,
                v.LicensePlate, cat.CategoryName,
                r.PickupLocationID, pl.Name AS PickupBranch,
                r.DropoffLocationID, dl.Name AS DropoffBranch,
                r.PickupDate, r.ReturnDate, r.DailyRate, r.TotalAmount, r.Status,
                r.PromoID, pr.Code AS PromoCode, pr.Discount
            FROM rentals r
            JOIN customers c ON r.CustomerID = c.CustomerID
            JOIN vehicles v ON r.VehicleID = v.VehicleID
            JOIN vehicle_categories cat ON v.CategoryID = cat.CategoryID
            JOIN rental_locations pl ON r.PickupLocationID = pl.LocationID
            JOIN rental_locations dl ON r.DropoffLocationID = dl.LocationID
            LEFT JOIN promotions pr ON r.PromoID = pr.PromoID
            WHERE r.RentalID = @id", new { id });
        return row == null ? NotFound() : Ok(row);
    }

    [HttpPost]
    public async Task<IActionResult> Create([FromBody] CreateRentalRequest req)
    {
        using var conn = _db.CreateConnection();
        var id = await conn.ExecuteScalarAsync<int>(@"
            INSERT INTO rentals (CustomerID, VehicleID, PickupLocationID, DropoffLocationID,
                PickupDate, ReturnDate, DailyRate, Status, PromoID)
            VALUES (@CustomerID, @VehicleID, @PickupLocationID, @DropoffLocationID,
                @PickupDate, @ReturnDate, @DailyRate, 'Active', @PromoID);
            SELECT SCOPE_IDENTITY();", req);
        return CreatedAtAction(nameof(GetById), new { id }, new { id });
    }

    [HttpPatch("{id}/status")]
    public async Task<IActionResult> UpdateStatus(int id, [FromBody] StatusUpdate update)
    {
        using var conn = _db.CreateConnection();
        var affected = await conn.ExecuteAsync(@"
            UPDATE rentals SET Status = @Status,
                ReturnDate = CASE WHEN @Status = 'Completed' AND ReturnDate IS NULL THEN GETDATE() ELSE ReturnDate END
            WHERE RentalID = @id", new { update.Status, id });
        return affected == 0 ? NotFound() : Ok(new { message = "Status updated" });
    }
}

public class StatusUpdate
{
    public string Status { get; set; } = "";
}
