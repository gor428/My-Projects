using CarRentalAPI.Data;
using CarRentalAPI.Models;
using Dapper;
using Microsoft.AspNetCore.Mvc;

namespace CarRentalAPI.Controllers;

[ApiController]
[Route("api/[controller]")]
public class VehiclesController : ControllerBase
{
    private readonly DbContext _db;
    public VehiclesController(DbContext db) => _db = db;

    [HttpGet]
    public async Task<IActionResult> GetAll([FromQuery] string? status)
    {
        using var conn = _db.CreateConnection();
        var where = string.IsNullOrEmpty(status) ? "" : "WHERE v.Status = @status";
        var rows = await conn.QueryAsync<Vehicle>($@"
            SELECT v.*, vc.CategoryName
            FROM vehicles v
            JOIN vehicle_categories vc ON v.CategoryID = vc.CategoryID
            {where}
            ORDER BY v.Make, v.Model", new { status });
        return Ok(rows);
    }

    [HttpGet("available")]
    public async Task<IActionResult> GetAvailable()
    {
        using var conn = _db.CreateConnection();
        var rows = await conn.QueryAsync<Vehicle>(@"
            SELECT v.*, vc.CategoryName
            FROM vehicles v
            JOIN vehicle_categories vc ON v.CategoryID = vc.CategoryID
            WHERE v.Status = 'Available'
            ORDER BY v.DailyRate");
        return Ok(rows);
    }
}

[ApiController]
[Route("api/[controller]")]
public class CustomersController : ControllerBase
{
    private readonly DbContext _db;
    public CustomersController(DbContext db) => _db = db;

    [HttpGet]
    public async Task<IActionResult> GetAll()
    {
        using var conn = _db.CreateConnection();
        var rows = await conn.QueryAsync<Customer>(@"
            SELECT * FROM customers ORDER BY RegistrationDate DESC");
        return Ok(rows);
    }

    [HttpGet("{id}/rental-count")]
    public async Task<IActionResult> GetRentalCount(int id)
    {
        using var conn = _db.CreateConnection();
        var count = await conn.ExecuteScalarAsync<int>(
            "SELECT COUNT(*) FROM rentals WHERE CustomerID = @id", new { id });
        return Ok(new { count });
    }

    [HttpPost]
    public async Task<IActionResult> Create([FromBody] Customer c)
    {
        using var conn = _db.CreateConnection();
        var id = await conn.ExecuteScalarAsync<int>(@"
            INSERT INTO customers (FirstName, LastName, Email, Phone, DateOfBirth, LicenseNumber, RegistrationDate)
            VALUES (@FirstName, @LastName, @Email, @Phone, @DateOfBirth, @LicenseNumber, GETDATE());
            SELECT SCOPE_IDENTITY();", c);
        return Ok(new { id });
    }
}

[ApiController]
[Route("api/[controller]")]
public class PaymentsController : ControllerBase
{
    private readonly DbContext _db;
    public PaymentsController(DbContext db) => _db = db;

    [HttpGet]
    public async Task<IActionResult> GetAll()
    {
        using var conn = _db.CreateConnection();
        var rows = await conn.QueryAsync<Payment>(@"
            SELECT p.PaymentID, p.RentalID,
                c.FirstName + ' ' + c.LastName AS CustomerName,
                p.Amount, p.Method, p.PaymentDate, p.Status
            FROM payments p
            JOIN rentals r ON p.RentalID = r.RentalID
            JOIN customers c ON r.CustomerID = c.CustomerID
            ORDER BY p.PaymentDate DESC");
        return Ok(rows);
    }

    [HttpPost]
    public async Task<IActionResult> Create([FromBody] Payment p)
    {
        using var conn = _db.CreateConnection();
        var id = await conn.ExecuteScalarAsync<int>(@"
            INSERT INTO payments (RentalID, Amount, Method, PaymentDate, Status)
            VALUES (@RentalID, @Amount, @Method, GETDATE(), @Status);
            SELECT SCOPE_IDENTITY();", p);
        return Ok(new { id });
    }
}

[ApiController]
[Route("api/[controller]")]
public class DamageReportsController : ControllerBase
{
    private readonly DbContext _db;
    public DamageReportsController(DbContext db) => _db = db;

    [HttpGet]
    public async Task<IActionResult> GetAll()
    {
        using var conn = _db.CreateConnection();
        var rows = await conn.QueryAsync<DamageReport>(@"
            SELECT dr.ReportID, dr.RentalID,
                v.Make + ' ' + v.Model AS VehicleInfo,
                v.LicensePlate,
                dr.InspectedBy, dr.Severity, dr.RepairCost,
                dr.InspectionDate, dr.Notes
            FROM damage_reports dr
            JOIN rentals r ON dr.RentalID = r.RentalID
            JOIN vehicles v ON r.VehicleID = v.VehicleID
            ORDER BY dr.InspectionDate DESC");
        return Ok(rows);
    }
}

[ApiController]
[Route("api/[controller]")]
public class LocationsController : ControllerBase
{
    private readonly DbContext _db;
    public LocationsController(DbContext db) => _db = db;

    [HttpGet]
    public async Task<IActionResult> GetAll()
    {
        using var conn = _db.CreateConnection();
        var rows = await conn.QueryAsync<RentalLocation>(@"
            SELECT * FROM rental_locations ORDER BY City, Name");
        return Ok(rows);
    }
}

[ApiController]
[Route("api/[controller]")]
public class PromotionsController : ControllerBase
{
    private readonly DbContext _db;
    public PromotionsController(DbContext db) => _db = db;

    [HttpGet("active")]
    public async Task<IActionResult> GetActive()
    {
        using var conn = _db.CreateConnection();
        var rows = await conn.QueryAsync<Promotion>(@"
            SELECT * FROM promotions WHERE ExpiryDate >= GETDATE() ORDER BY Discount DESC");
        return Ok(rows);
    }
}

[ApiController]
[Route("api/[controller]")]
public class ReportsController : ControllerBase
{
    private readonly DbContext _db;
    public ReportsController(DbContext db) => _db = db;

    [HttpGet("revenue-by-location")]
    public async Task<IActionResult> RevenueByLocation()
    {
        using var conn = _db.CreateConnection();
        var rows = await conn.QueryAsync(@"
            SELECT rl.Name AS LocationName, rl.City,
                COUNT(r.RentalID) AS TotalRentals,
                ISNULL(SUM(r.TotalAmount), 0) AS TotalRevenue
            FROM rental_locations rl
            LEFT JOIN rentals r ON rl.LocationID = r.PickupLocationID AND r.Status = 'Completed'
            GROUP BY rl.LocationID, rl.Name, rl.City
            ORDER BY TotalRevenue DESC");
        return Ok(rows);
    }

    [HttpGet("damage-summary")]
    public async Task<IActionResult> DamageSummary()
    {
        using var conn = _db.CreateConnection();
        var rows = await conn.QueryAsync(@"
            SELECT Severity, COUNT(*) AS Count,
                ISNULL(SUM(RepairCost), 0) AS TotalRepairCost
            FROM damage_reports
            GROUP BY Severity
            ORDER BY CASE Severity WHEN 'None' THEN 0 WHEN 'Minor' THEN 1 WHEN 'Moderate' THEN 2 WHEN 'Severe' THEN 3 END");
        return Ok(rows);
    }

    [HttpGet("top-customers")]
    public async Task<IActionResult> TopCustomers()
    {
        using var conn = _db.CreateConnection();
        var rows = await conn.QueryAsync(@"
            SELECT TOP 10 c.CustomerID,
                c.FirstName + ' ' + c.LastName AS CustomerName,
                COUNT(r.RentalID) AS TotalRentals,
                ROUND(SUM(r.TotalAmount), 2) AS TotalSpent,
                ROUND(AVG(r.TotalAmount), 2) AS AvgPerRental
            FROM customers c
            JOIN rentals r ON c.CustomerID = r.CustomerID
            WHERE r.Status = 'Completed'
            GROUP BY c.CustomerID, c.FirstName, c.LastName
            ORDER BY TotalSpent DESC");
        return Ok(rows);
    }
}
