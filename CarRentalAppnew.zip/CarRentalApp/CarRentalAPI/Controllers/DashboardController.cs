using CarRentalAPI.Data;
using CarRentalAPI.Models;
using Dapper;
using Microsoft.AspNetCore.Mvc;

namespace CarRentalAPI.Controllers;

[ApiController]
[Route("api/[controller]")]
public class DashboardController : ControllerBase
{
    private readonly DbContext _db;
    public DashboardController(DbContext db) => _db = db;

    [HttpGet("stats")]
    public async Task<IActionResult> GetStats()
    {
        using var conn = _db.CreateConnection();
        var stats = await conn.QueryFirstAsync<DashboardStats>(@"
            SELECT
                (SELECT COUNT(*) FROM rentals WHERE Status IN ('Active','Scheduled')) AS ActiveRentals,
                (SELECT COUNT(*) FROM vehicles WHERE Status = 'Available') AS AvailableVehicles,
                (SELECT COUNT(*) FROM vehicles) AS TotalVehicles,
                (SELECT COUNT(*) FROM customers) AS TotalCustomers,
                (SELECT ISNULL(SUM(p.Amount),0) FROM payments p
                 JOIN rentals r ON p.RentalID = r.RentalID
                 WHERE p.Status = 'Paid'
                 AND MONTH(p.PaymentDate) = MONTH(GETDATE())
                 AND YEAR(p.PaymentDate) = YEAR(GETDATE())) AS MonthRevenue,
                (SELECT COUNT(*) FROM payments WHERE Status = 'Pending') AS PendingPayments,
                (SELECT ISNULL(SUM(Amount),0) FROM payments WHERE Status = 'Pending') AS PendingAmount
        ");
        return Ok(stats);
    }

    [HttpGet("category-stats")]
    public async Task<IActionResult> GetCategoryStats()
    {
        using var conn = _db.CreateConnection();
        var rows = await conn.QueryAsync<CategoryStat>(@"
            SELECT vc.CategoryName,
                COUNT(v.VehicleID) AS Total,
                SUM(CASE WHEN v.Status = 'Available' THEN 1 ELSE 0 END) AS Available,
                SUM(CASE WHEN v.Status = 'Rented' THEN 1 ELSE 0 END) AS Rented
            FROM vehicle_categories vc
            LEFT JOIN vehicles v ON vc.CategoryID = v.CategoryID
            GROUP BY vc.CategoryName
            ORDER BY Total DESC
        ");
        return Ok(rows);
    }

    [HttpGet("upcoming-returns")]
    public async Task<IActionResult> GetUpcomingReturns()
    {
        using var conn = _db.CreateConnection();
        var rows = await conn.QueryAsync<Rental>(@"
            SELECT r.RentalID,
                c.FirstName + ' ' + c.LastName AS CustomerName,
                v.Make + ' ' + v.Model AS VehicleInfo,
                v.LicensePlate,
                pl.Name AS PickupBranch,
                dl.Name AS DropoffBranch,
                r.PickupDate, r.ReturnDate, r.DailyRate, r.TotalAmount, r.Status
            FROM rentals r
            JOIN customers c ON r.CustomerID = c.CustomerID
            JOIN vehicles v ON r.VehicleID = v.VehicleID
            JOIN rental_locations pl ON r.PickupLocationID = pl.LocationID
            JOIN rental_locations dl ON r.DropoffLocationID = dl.LocationID
            WHERE r.Status IN ('Active','Scheduled')
              AND r.ReturnDate <= DATEADD(day, 3, GETDATE())
            ORDER BY r.ReturnDate ASC
        ");
        return Ok(rows);
    }
}
