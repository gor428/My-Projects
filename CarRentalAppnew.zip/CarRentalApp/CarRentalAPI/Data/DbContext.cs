using Microsoft.Data.SqlClient;
using System.Data;

namespace CarRentalAPI.Data;

public class DbContext
{
    private readonly string _connectionString;

    public DbContext(string connectionString)
    {
        _connectionString = connectionString;
    }

    public IDbConnection CreateConnection() => new SqlConnection(_connectionString);
}
