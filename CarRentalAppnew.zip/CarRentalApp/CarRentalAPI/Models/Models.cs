namespace CarRentalAPI.Models;

public class Customer
{
    public int CustomerID { get; set; }
    public string FirstName { get; set; } = "";
    public string LastName { get; set; } = "";
    public string Email { get; set; } = "";
    public string? Phone { get; set; }
    public DateTime DateOfBirth { get; set; }
    public string LicenseNumber { get; set; } = "";
    public DateTime RegistrationDate { get; set; }
}

public class VehicleCategory
{
    public int CategoryID { get; set; }
    public string CategoryName { get; set; } = "";
    public string? Description { get; set; }
}

public class Vehicle
{
    public int VehicleID { get; set; }
    public int CategoryID { get; set; }
    public string? CategoryName { get; set; }
    public string Make { get; set; } = "";
    public string Model { get; set; } = "";
    public int Year { get; set; }
    public string LicensePlate { get; set; } = "";
    public string? Color { get; set; }
    public double DailyRate { get; set; }
    public string Status { get; set; } = "Available";
    public int? Mileage { get; set; }
}

public class RentalLocation
{
    public int LocationID { get; set; }
    public string Name { get; set; } = "";
    public string? Address { get; set; }
    public string? City { get; set; }
    public int FleetCapacity { get; set; }
}

public class Promotion
{
    public int PromoID { get; set; }
    public string Code { get; set; } = "";
    public double Discount { get; set; }
    public DateTime ExpiryDate { get; set; }
}

public class Rental
{
    public int RentalID { get; set; }
    public int CustomerID { get; set; }
    public string? CustomerName { get; set; }
    public int VehicleID { get; set; }
    public string? VehicleInfo { get; set; }
    public string? LicensePlate { get; set; }
    public string? CategoryName { get; set; }
    public int PickupLocationID { get; set; }
    public string? PickupBranch { get; set; }
    public int DropoffLocationID { get; set; }
    public string? DropoffBranch { get; set; }
    public DateTime PickupDate { get; set; }
    public DateTime? ReturnDate { get; set; }
    public double DailyRate { get; set; }
    public double? TotalAmount { get; set; }
    public string Status { get; set; } = "Scheduled";
    public int? PromoID { get; set; }
    public string? PromoCode { get; set; }
    public double? Discount { get; set; }
}

public class CreateRentalRequest
{
    public int CustomerID { get; set; }
    public int VehicleID { get; set; }
    public int PickupLocationID { get; set; }
    public int DropoffLocationID { get; set; }
    public DateTime PickupDate { get; set; }
    public DateTime? ReturnDate { get; set; }
    public double DailyRate { get; set; }
    public int? PromoID { get; set; }
}

public class Payment
{
    public int PaymentID { get; set; }
    public int RentalID { get; set; }
    public string? CustomerName { get; set; }
    public double Amount { get; set; }
    public string Method { get; set; } = "Card";
    public DateTime PaymentDate { get; set; }
    public string Status { get; set; } = "Pending";
}

public class DamageReport
{
    public int ReportID { get; set; }
    public int RentalID { get; set; }
    public string? VehicleInfo { get; set; }
    public string? LicensePlate { get; set; }
    public string? InspectedBy { get; set; }
    public string Severity { get; set; } = "None";
    public double? RepairCost { get; set; }
    public DateTime? InspectionDate { get; set; }
    public string? Notes { get; set; }
}

public class DashboardStats
{
    public int ActiveRentals { get; set; }
    public int AvailableVehicles { get; set; }
    public double MonthRevenue { get; set; }
    public int PendingPayments { get; set; }
    public double PendingAmount { get; set; }
    public int TotalVehicles { get; set; }
    public int TotalCustomers { get; set; }
}

public class CategoryStat
{
    public string CategoryName { get; set; } = "";
    public int Total { get; set; }
    public int Available { get; set; }
    public int Rented { get; set; }
}
