using CarRentalAPI.Data;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();

var connStr = builder.Configuration.GetConnectionString("CarRentalDB")!;
builder.Services.AddSingleton(new DbContext(connStr));

builder.Services.AddCors(options =>
{
    options.AddDefaultPolicy(policy =>
        policy.AllowAnyOrigin().AllowAnyMethod().AllowAnyHeader());
});

var app = builder.Build();
app.UseCors();
app.MapControllers();
app.Run();
