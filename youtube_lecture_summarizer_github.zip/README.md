# YouTube Lecture Summarizer

An AI-powered app that summarizes YouTube lectures by combining automatic transcription and natural language summarization.

## ✨ Features
- 🎙️ Transcribe lecture audio with OpenAI Whisper
- 🧠 Generate concise summaries using Hugging Face Transformers
- 🌐 User-friendly interface built with Streamlit
- 🚀 Public sharing enabled via pyngrok
- ✅ ADA-compliant: keyboard accessible and text-based output

## 🛠 Technologies Used
- OpenAI Whisper (speech recognition)
- DistilBART (`distilbart-cnn-12-6`) summarizer from Hugging Face
- Streamlit (web interface)
- pytube (YouTube audio extraction)
- pyngrok (tunneling for public demos)

## 🚀 How to Run Locally
1. Clone the repository
2. Install dependencies:
   ```
   pip install -r requirements.txt
   ```
3. Launch the app:
   ```
   streamlit run app.py
   ```

## 📹 Demo
Watch the full demo on YouTube:  
👉 https://youtu.be/Apmboz1lByw

## 📂 Repository Structure
- `app.py` – Main application script
- `requirements.txt` – Required Python libraries
- `README.md` – Project overview

## 👨‍💻 Author
**Gor Babayan**  
Project S2 — UFAR  
April 2025

