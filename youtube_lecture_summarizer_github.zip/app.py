
import streamlit as st
from pytube import YouTube
import whisper
from transformers import pipeline
import os
import tempfile

st.title("🎓 YouTube Lecture Summarizer")

url = st.text_input("Enter YouTube URL")
if st.button("Summarize") and url:
    with st.spinner("Downloading video..."):
        yt = YouTube(url)
        stream = yt.streams.filter(only_audio=True).first()
        temp_file = tempfile.NamedTemporaryFile(delete=False, suffix=".mp4")
        stream.download(filename=temp_file.name)

    with st.spinner("Transcribing..."):
        model = whisper.load_model("tiny")
        result = model.transcribe(temp_file.name)
        transcript = result["text"]

    with st.spinner("Summarizing..."):
        summarizer = pipeline("summarization", model="sshleifer/distilbart-cnn-12-6")
        chunks = [transcript[i:i+1000] for i in range(0, len(transcript), 1000)]
        summary = ""
        for chunk in chunks:
            summary += summarizer(chunk, max_length=150, min_length=30, do_sample=False)[0]['summary_text'] + "\n"

    st.subheader("Summary:")
    st.write(summary)
    os.remove(temp_file.name)
